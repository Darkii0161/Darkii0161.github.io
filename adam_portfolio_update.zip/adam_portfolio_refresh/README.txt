ADAM IBRAHIM PORTFOLIO UPDATE

Files included:
- index.html
- style.css
- script.js
- assets/icons/ (the seven white SVG tool/language icons)

To use this update on GitHub Pages:
1. Download and extract the ZIP.
2. In your GitHub repository, replace index.html and style.css with these versions.
3. Upload script.js and the entire assets folder, keeping the folder structure exactly as shown.
4. Commit the changes.
5. Open the website and hard refresh with Ctrl+F5 (Windows).

The icons are local SVG files, so they do not rely on an external icon website.

To make text bold in the HTML, wrap it in <strong> and </strong>:
<strong>This text will be bold.</strong>
